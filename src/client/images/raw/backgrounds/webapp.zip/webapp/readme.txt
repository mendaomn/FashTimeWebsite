NOTA

Il framework Bootstrap e le componenti UI-Bootstrap per AngularJS non sono state inserite all'interno del package.json 
in quanto sono richieste versioni modificate delle stesse per rispondere ai requisiti funzionali e visuali.

Le versioni modificate sono fornite all'interno del presente pacchetto.

- Bootstrap 3.3.6		assets/vendor/bootstrap-3.3.6-dist
- UI Bootstrap 1.2.5	assets/vendor/ui-bootstrap-tpls-1.2.5.js