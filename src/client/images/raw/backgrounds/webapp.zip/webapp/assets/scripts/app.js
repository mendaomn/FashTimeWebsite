(function() {

    'use strict';

    var app = angular.module('centroCompetenza', [
        'ui.bootstrap',
        'ngAnimate',
        'ispCommunicationManager',
        'ispServiceRequest',
        'ispServiceResponse',
        'ispProfileManager',
        'ispErrorManager',
        'ispLogging',
        'ispStorage',
        'ispMenu',
        'ispHeader',
        'ispAccordion',
        'ispDropdown',
        'ispCombo',
        'ispDatepicker',
        'ispInput',
        'ispCheckbox',
        'ispRadio',
        'ispButton',
        'ispSwitch',
        'ispResults',
        'ispTable',
        'ispLabel',
        'ispFooter',
        'ispTab',
        'ispModal',
        'ispLoading',
        'home',
        'test',
        'censimentoCliente'
    ])

    .config(['$stateProvider', function($stateProvider) {

        $stateProvider.state({
            name: 'home',
            url: '/',
            templateUrl: 'content/home.tpl.html',
            controller: 'HomeCtrl',
            data: {
                workflowStepName: 'PAGINA 2'
            }
        });

        $stateProvider.state({
            name: 'test',
            url: '/test',
            templateUrl: 'content/test.tpl.html',
            controller: 'TestCtrl',
        });

        $stateProvider.state({
            name: 'datiAnagrafici',
            url: '/dati_anagrafici',
            templateUrl: 'content/censimentoCliente/datiAnagrafici.tpl.html',
            controller: 'CensimentoClienteCtrl',
            data: {
                workflowStepName: 'DATI ANAGRAFICI'
            }
        });

        $stateProvider.state({
            name: 'datiComunicazione',
            url: '/dati_comunicazione',
            templateUrl: 'content/censimentoCliente/datiComunicazione.tpl.html',
            controller: 'CensimentoClienteCtrl',
            data: {
                workflowStepName: 'DATI COMUNICAZIONE'
            }
        });

        $stateProvider.state({
            name: 'datiFacoltativi',
            url: '/dati_facoltativi',
            templateUrl: 'content/censimentoCliente/datiFacoltativi.tpl.html',
            controller: 'CensimentoClienteCtrl',
            data: {
                workflowStepName: 'DATI FACOLTATIVI'
            }
        });
    }])

    .run(['$rootScope', '$state', '$window', function($rootScope, $state, $window) {
        
        $rootScope.censimentoClienteSteps = [{
            name: "Step 1",
            value: 0,
            active: false,
            pages: [{
                name: "DATI ANAGRAFICI",
                status: 0
            }, {
                name: "DATI COMUNICAZIONE",
                status: 0
            }]
        }, {
            name: "Step 2",
            value: 0,
            active: false,
            pages: [{
                name: "DATI FACOLTATIVI",
                status: 0
            }]
        }];

        $rootScope.homeSteps = [{
            name: "Step 1",
            value: 0,
            active: true,
            pages: [{
                name: "PAGINA 1",
                status: 2
            }, {
                name: "PAGINA 2",
                status: 1
            }, {
                name: "PAGINA 3",
                status: 0
            }, {
                name: "PAGINA 4",
                status: 0
            }, {
                name: "PAGINA 5",
                status: 0
            }]
        }, {
            name: "Step 2",
            value: 0,
            active: false,
            pages: []
        },  {
            name: "Step 3",
            value: 0,
            active: false,
            pages: []
        },  {
            name: "Step 4",
            value: 0,
            active: false,
            pages: []
        }];

        $rootScope.goToState = function(state) {
            $state.go(state);
        };

        $state.transitionTo('home');
    }])

    .controller('AppCtrl', function($scope, $rootScope, $timeout, $state, ispLogging, ispStorage) {

        // storage example
        $rootScope.sessionStorage = ispStorage.newSessionStorage();
        $rootScope.localStorage = ispStorage.newLocalStorage();


        // logging example
        ispLogging.setUrl('http://localhost:7001/DEMO/logging/application');

        ispLogging.fatal('Messaggio di errore fatale');
        ispLogging.error('Messaggio di errore');
        ispLogging.warn('Messaggio di warning');
        ispLogging.info('Log informativo');
        ispLogging.debug('Log di debug');
        ispLogging.trace('Trace dello stack');

        // menu example
        $scope.menu = [{
            buttons: [{
                name: 'La mia situazione',
                url: 'url1',
                icon: 'ico-menu-lamiasituazione',
                key: 'b1'
            }, {
                name: 'Conti',
                url: 'url2',
                icon: 'ico-menu-conti',
                key: 'b2'
            }, {
                name: 'Carte',
                url: 'url3',
                icon: 'ico-menu-carte',
                key: 'b3'
            }, {
                name: 'Pagamenti digitali',
                url: 'url4',
                icon: 'ico-menu-borsellinidigitali',
                key: 'b4'
            }]
        }, {
            buttons: [{
                name: 'Finanziamenti',
                url: 'url5',
                icon: 'ico-menu-finanziamenti',
                secondLevel: [{
                    buttons: [{
                        name: 'Pulsante 1',
                        url: ''
                    }, {
                        name: 'Pulsante 2',
                        url: ''
                    }]
                }],
                key: 'b5'
            }, {
                name: 'Investimenti',
                url: 'url6',
                icon: 'ico-menu-risparmioeprevidenza',
                secondLevel: [{
                    buttons: [{
                        name: 'I miei investimenti',
                        url: ''
                    }, {
                        name: 'Azioni',
                        url: ''
                    }, {
                        name: 'Obbligazioni',
                        url: ''
                    }, {
                        name: 'ETF e ETC',
                        url: ''
                    }, {
                        name: 'Certificates e derivati',
                        url: ''
                    }]
                }, {
                    buttons: [{
                        name: 'I nostri prodotti d\'investimento',
                        url: ''
                    }, {
                        name: 'Tutti i fondi comuni',
                        url: ''
                    }, {
                        name: 'Prenotazione titoli di Stato',
                        url: ''
                    }, {
                        name: 'Ricerca titoli e fondi',
                        url: ''
                    }]
                }, {
                    buttons: [{
                        name: 'Marketwall',
                        url: ''
                    }, {
                        name: 'Notizie di mercato e ricerche',
                        url: ''
                    }, {
                        name: 'Lista preferiti',
                        url: ''
                    }, {
                        name: 'Posizione fiscale',
                        url: ''
                    }, {
                        name: 'Lista operazioni',
                        url: ''
                    }]
                }],
                key: 'b6'
            }]
        }, {
            buttons: [{
                name: 'Piani di risparmio e previdenza',
                url: 'url7',
                icon: 'ico-pfm-isp-font-cat-259',
                key: 'b7'
            }, {
                name: 'Assicurazioni',
                url: 'url8',
                icon: 'ico-menu-assicurazioni',
                key: 'b8'
            }, {
                name: 'Offerte per me',
                url: 'url9',
                icon: 'ico-menu-perme',
                key: 'b9'
            }]
        }];

        $scope.loggedUser = {
            image: 'content/user-profile.jpg',
            name: 'Emiliana Maria',
            surname: 'Casetti',
            subtitle: 'Il mio profilo',
            callback: function() {
                console.log('User profile callback');
            }
        };

        // footer example
        $scope.links = [{
            name: 'Link 1',
            internalState: false,
            url: 'http://www.google.it'
        }, {
            name: 'Link 2',
            internalState: true,
            url: 'link/a/stato/interno/'
        }, {
            name: 'Link 3',
            internalState: false,
            url: 'www.google.it'
        }, {
            name: 'Link 4',
            internalState: false,
            url: 'www.google.it'
        }, {
            name: 'Link 5',
            internalState: false,
            url: 'www.google.it'
        }];

        $scope.footerCentralBtn = {
            name: 'FOOTER BUTTON',
            icon: 'ico-menu-carte',
            click: function() {
                console.log('Footer Button click');
            }
        };

        $rootScope.scopes = [];

        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {

            window.scrollTo(0, 0);

            if ($state.current.name === 'home') {
                $rootScope.steps = $rootScope.homeSteps;
                $rootScope.sessionStorage.clear();
            }

            if ($state.current.name !== 'home') {
                $rootScope.steps = $rootScope.censimentoClienteSteps;
            }
            
            $timeout(function() {
                $rootScope.$broadcast('stateChangeSuccess', { event: event, toState: toState, toParams: toParams, fromState: fromState, fromParams: fromParams });
            });
        });
    })

})();