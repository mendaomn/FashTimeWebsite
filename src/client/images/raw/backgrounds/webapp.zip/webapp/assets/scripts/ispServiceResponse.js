(function() {

    'use strict';

    angular
    .module('ispServiceResponse', [])
    .service('ispServiceResponse', function() {

        this.fillIfNull = function(x, y) {
            return x || y;
        };

        this.initObject = function(x) {
            
            var exitCode = '';
            var payload = {};
            var message = '';
            var messages = [];
            var execTime = 0;

            if (x) {
                exitCode = this.fillIfNull(x.exitCode, '');
                payload = this.fillIfNull(x.payload, {});
                message = this.fillIfNull(x.message, '');
                messages = this.fillIfNull(x.messages, []);
                execTime = this.fillIfNull(x.execTime, 0);
            }

            return {
                exitCode: exitCode,
                payload: payload,
                message: message,
                messages: messages,
                execTime: execTime
            };
        };
    });

})();