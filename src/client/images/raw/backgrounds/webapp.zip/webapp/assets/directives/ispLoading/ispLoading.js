(function() {

    'use strict';

    var ispLoading = angular.module('ispLoading', []);

    ispLoading.directive('ispLoading', [function() {

        return {
            templateUrl: 'assets/directives/ispLoading/ispLoading.tpl.html',
            scope: {
                showAnimation: '=',
                arcsNumber: '@?',
                arcsGap: '@?',
                arcsWidth: '@?',
                radius: '@?',
                speed: '@?'
            },

            controller: function($scope, $timeout, $interval) {

                var canvas,
                    context,
                    x, y,
                    current = 0,
                    gap,
                    stopTime,
                    deactiveColor = '#b4d2a4',
                    activeColor = '#258900';

                $scope.arcs = [];
                $scope.dimension = 0;

                if (!$scope.arcsNumber) {
                    $scope.arcsNumber = 8;
                }

                if (!$scope.arcsGap) {
                    $scope.arcsGap = 4;
                }

                if (!$scope.arcsWidth) {
                    $scope.arcsWidth = 6;
                }

                if (!$scope.radius) {
                    $scope.radius = 32;
                }

                if (!$scope.speed) {
                    $scope.speed = 120;
                }

                x = y = ($scope.radius * 2 + 32) / 2;
                gap = ($scope.arcsGap / 2) * 0.01;

                $scope.dimension = $scope.radius * 2 + 32;

                document.getElementsByClassName('isp-loading-spinner')[0].style.marginTop = '-' + $scope.dimension / 2 + 'px';
                document.getElementsByClassName('isp-loading-spinner')[0].style.marginLeft = '-' + $scope.dimension / 2 + 'px';

                for (var i = 0; i < $scope.arcsNumber; i++) {
                    $scope.arcs.push({ id: 'isp-loading-arc-' + i });
                }

                self.getAngle = function(index, gap) {
                    return (((2 * index) / $scope.arcs.length) + gap) * Math.PI;
                };

                self.drawCanvas = function(index, color) {

                    canvas = document.getElementById('isp-loading-arc-' + index);
                    context = canvas.getContext('2d');
                    context.clearRect(0, 0, $scope.dimension, $scope.dimension);
                    context.beginPath();
                    context.arc(x, y, $scope.radius, self.getAngle(index, gap), self.getAngle(index + 1, -gap));
                    context.strokeStyle = color;
                    context.lineWidth = $scope.arcsWidth;
                    context.stroke();
                };

                self.startAnimation = function() {

                    var j;

                    if (current === $scope.arcs.length) {
                        current = 0;
                    }

                    if (current === 0) {
                        j = $scope.arcs.length - 1;
                    } else {
                        j = current - 1;
                    }

                    self.drawCanvas(current, activeColor);
                    self.drawCanvas(j, deactiveColor);

                    current++;
                };

                $timeout(function() {

                    for (var i = 0; i < $scope.arcs.length; i++) {
                        self.drawCanvas(i, deactiveColor);
                    }

                    $scope.$watch('showAnimation', function(newValue) {

                        if (newValue) {

                            stopTime = $interval(function() {
                                self.startAnimation();
                            }, $scope.speed);

                        } else {
                            $interval.cancel(stopTime);
                        }
                    });
                });
            }
        };
    }]);

})();