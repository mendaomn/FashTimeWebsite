(function() {

    'use strict';

    var ispMenu = angular.module('ispMenu', ['ispProfileManager']);

    ispMenu.directive('ispMenu', [function() {

        return {
            templateUrl: 'assets/directives/ispMenu_2.0/ispMenu.tpl.html',
            scope: {
                menu: '=',
                user: '=?',
                onClickFn: '&?'
            },

            controller: function($scope, $rootScope, $location, $timeout) {

                $scope.isOpen = false;
                $scope.selected = {};
                $scope.showUserButton = false;
                $scope.imageLoaded = false;
                $scope.showSecondLevelMenu = false;

                if ($scope.user) {
                    $scope.showUserButton = true;
                }

                $rootScope.$on("openCloseMenu", function(event, data) {
                    $scope.isOpen = data;
                });

                $scope.goBack = function() {
                    $scope.selected = {};
                    $scope.showSecondLevelMenu = false;
                };

                $scope.onClick = function(button) {

                    if (button.secondLevel) {
                        $scope.selected = button;
                        return;
                    }

                    if ($scope.onClickFn) {
                        $scope.onClickFn();
                    }

                    $location.path(button.url);
                };

                $scope.showSecondLevel = function() {
                    $timeout(function() {
                        $scope.showSecondLevelMenu = true;
                        document.getElementsByClassName('second-level-menu')[0].scrollTop = 0;
                    });
                };
            }
        };
    }]);

    ispMenu.directive('ispOnload', function() {

        return {
            restrict: 'A',

            link: function(scope, element, attrs) {

                scope.imageError = false;

                element.bind('load', function() {
                    scope.$apply(attrs.ispOnload);
                });

                element.bind('error', function() {
                    scope.imageError = true;
                });
            }
        };
    })

})();