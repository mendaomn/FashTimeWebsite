(function() {

    'use strict';

    angular
    .module('home', [])
    .controller('HomeCtrl', function($scope, $rootScope, $timeout, ispErrorManager) {

        // header example
        $rootScope.pageTitle = 'DEMO';
        $rootScope.pageSubtitle = 'Demo';

        // accordion example
        $scope.accordionContents = [{
            title: 'Titolo Accordion 1',
            content: 'content/accordion-content1.html',
            innerContents: [{
                title: 'Titolo Accordion 1.1',
                content: 'content/accordion-content1.1.html',
                innerContents: [{
                    title: 'Titolo Accordion 1.1.1',
                    content: 'content/accordion-content.html',
                }, {
                    title: 'Titolo Accordion 1.1.2',
                    content: 'content/accordion-content.html',
                }]
            }, {
                title: 'Titolo Accordion 1.2',
                content: 'content/accordion-content.html',
                innerContents: []
            }]
        }];

        // dropdown example
        $scope.dropdownItems = [{
            name: 'Italia',
            value: '0'
        }, {
            name: 'Germania',
            value: '1'
        }, {
            name: 'Francia',
            value: '2'
        }, {
            name: 'Finlandia',
            value: '3'
        }, {
            name: 'Spagna',
            value: '4'
        }, {
            name: 'Svizzera',
            value: '5'
        }];

        // combobox example
        $scope.comboItems = [{
            name: 'Opzione 1',
            value: '0'
        }, {
            name: 'Opzione 2',
            value: '1'
        }, {
            name: 'Opzione 3',
            value: '2'
        }, {
            name: 'Opzione 4',
            value: '3'
        }, {
            name: 'Opzione 5',
            value: '4'
        }, {
            name: 'Opzione 6',
            value: '5'
        }, {
            name: 'Opzione 7',
            value: '6'
        }];

        $scope.selectedDropdownItem = null;
        $scope.selectedComboItem = $scope.comboItems[1];

        // datepicker example
        $scope.date = null;

        // input example
        $scope.input = '';
        $scope.inputPassword = '';

        $scope.onInputFocus = function() {
            console.log("input focus");
        };

        $scope.onInputBlur = function() {
            console.log("input blur");
        };

        $scope.onInputChange = function() {
            console.log("input change");
        };

        // checkbox & radio example
        $scope.checkbox = false;
        $scope.checkbox_ = true;
        $scope.radio = 1;
        $scope.radio_ = 3;

        // button example
        $scope.onButtonClick = function() {
            console.log("button clicked");
        }

        // error manager example
        $scope.genericErrorCallback = function(data) {
            console.log(data);
        };

        ispErrorManager.setGenericErrorCodes(['100', '200']);
        ispErrorManager.setSpecificErrorCodes(['300']);
        ispErrorManager.setGenericErrorCallback($scope.genericErrorCallback);

        $scope.validate = function() {

            /* MOCK (returned data from service) */
            var data = {
                esito: {
                    returnCode: '5',
                    messages: [{
                        code: 'dropdown-1',
                        type: '',
                        description: 'Il Paese selezionato non è corretto.'
                    }, {
                        code: 'combobox-1',
                        type: '',
                        description: 'L\'opzione selezionata non è corretta.'
                    }, {
                        code: 'date-1',
                        type: '',
                        description: 'La data inserita non è corretta.'
                    }, {
                        code: 'input-1',
                        type: '',
                        description: 'Il codice fiscale inserito non è corretto.'
                    }],
                    executionTime: 5498798765321,
                    statoEsito: false
                }
            };
            /* END MOCK */

            ispErrorManager.manageError(data);
        };

        // loading example
        $rootScope.loading = false;

        $scope.loadingExample = function() {

            $rootScope.loading = true;

            $timeout(function() {
                $rootScope.loading = false;
            }, 2000);
        };

        // info modal example
        $scope.infoModalTitle = 'TITOLO MODALE INFORMATIVA';
        $scope.infoModalData = "Questa è una modale informativa.";
        $scope.infoModalOpened = false;

        $scope.openInfoModal = function() {
            $scope.infoModalOpened = true;
        };

        $scope.confirmModalFn = function() {
            console.log('Conferma');
        };

        // upload modal example
        $scope.uploadModalData = "Questa è una modale per il caricamento di un singolo documento.";
        $scope.uploadModalOpened = false;

        $scope.openUploadModal = function() {
            $scope.uploadModalOpened = true;
        };

        // upload modal multiple files example
        $scope.uploadModalMultiData = "Questa è una modale per il caricamento di più documenti.";
        $scope.uploadModalMultiOpened = false;

        $scope.openUploadModalMulti = function() {
            $scope.uploadModalMultiOpened = true;
        };

        $scope.uploadServiceUrl = 'https://angular-file-upload-cors-srv.appspot.com/upload';

        // esito modal example
        $scope.result = true;
        $scope.esitoModalTitle = 'SALVA "titolo operazione in corso"';
        $scope.esitoModalData = "Hai scelto di salvare l'operazione in corso. La trovi in \"Ricordami di ...\" e puoi completarla in un secondo momento.";
        $scope.esitoModalOpened = false;

        $scope.openEsitoModal = function() {
            $scope.esitoModalOpened = true;
        };

        // switch example
        $scope.switchChoices = [{
            label: 'Cittadino Residente Italiano',
            icon: 'ico-ops-cittadinanzaitaliana'
        }, {
            label: 'Cittadino Residente Estero',
            icon: 'ico-ops-cittadinanzaestera'
        }];

        $scope.selectedSwitch = null;

        $scope.onSwitchSelection = function() {
            console.log($scope.selectedSwitch);
        }

        // tab example 
        $scope.tabs = [{
            name: 'Scheda 1',
            icon: '',
            content: 'content/tab-content-1.html',
            selected: true,
            disabled: false
        }, {
            name: 'Scheda 2',
            icon: 'ico-menu-lemiebanche',
            content: 'content/tab-content-2.html',
            selected: false,
            disabled: false
        }, {
            name: 'Scheda 3',
            icon: '',
            content: '',
            selected: false,
            disabled: true
        }];

        // results example
        $scope.resultsLabels = [
            'Campo 1',
            'Campo 2',
            'Campo 3',
            'Campo 4'
        ];

        $scope.results = [{
            'Campo 1': 'Contenuto 1.1',
            'Campo 2': 'Contenuto 1.2',
            'Campo 3': 'Contenuto 1.3',
            'Campo 4': 'Contenuto 1.4'
        }, {
            'Campo 1': 'Contenuto 2.1',
            'Campo 2': 'Contenuto 2.2',
            'Campo 3': 'Contenuto 2.3',
            'Campo 4': 'Contenuto 2.4'
        }, {
            'Campo 1': 'Contenuto 3.1',
            'Campo 2': 'Contenuto 3.2',
            'Campo 3': 'Contenuto 3.3',
            'Campo 4': 'Contenuto 3.4'
        }];

        $scope.selectedResult = null;
        $scope.selectedResults = [];

        $scope.onResultClick = function() {
            console.log($scope.selectedResult, $scope.selectedResults);
        };

        // table example
        $scope.tableLabels = [
            'Colonna 1',
            'Colonna 2',
            'Colonna 3',
            'Colonna 4',
        ];

        $scope.tableContents = [{
            'Colonna 1': 'A',
            'Colonna 2': 'Contenuto 1.2',
            'Colonna 3': 'Contenuto 1.3',
            'Colonna 4': 'Contenuto 1.4'
        }, {
            'Colonna 1': 'B',
            'Colonna 2': 'Contenuto 2.2',
            'Colonna 3': 'Contenuto 2.3',
            'Colonna 4': 'Contenuto 2.4'
        }, {
            'Colonna 1': 'C',
            'Colonna 2': 'Contenuto 3.2',
            'Colonna 3': 'Contenuto 3.3',
            'Colonna 4': 'Contenuto 3.4'
        }, {
            'Colonna 1': 'D',
            'Colonna 2': 'Contenuto 4.2',
            'Colonna 3': 'Contenuto 4.3',
            'Colonna 4': 'Contenuto 4.4'
        }, {
            'Colonna 1': 'E',
            'Colonna 2': 'Contenuto 5.2',
            'Colonna 3': 'Contenuto 5.3',
            'Colonna 4': 'Contenuto 5.4'
        }, {
            'Colonna 1': 'F',
            'Colonna 2': 'Contenuto 6.2',
            'Colonna 3': 'Contenuto 6.3',
            'Colonna 4': 'Contenuto 6.4'
        }, {
            'Colonna 1': 'G',
            'Colonna 2': 'Contenuto 7.2',
            'Colonna 3': 'Contenuto 7.3',
            'Colonna 4': 'Contenuto 7.4'
        }, {
            'Colonna 1': 'H',
            'Colonna 2': 'Contenuto 8.2',
            'Colonna 3': 'Contenuto 8.3',
            'Colonna 4': 'Contenuto 8.4'
        }, {
            'Colonna 1': 'I',
            'Colonna 2': 'Contenuto 9.2',
            'Colonna 3': 'Contenuto 9.3',
            'Colonna 4': 'Contenuto 9.4'
        }, {
            'Colonna 1': 'L',
            'Colonna 2': 'Contenuto 10.2',
            'Colonna 3': 'Contenuto 10.3',
            'Colonna 4': 'Contenuto 10.4'
        }];

    });

})();