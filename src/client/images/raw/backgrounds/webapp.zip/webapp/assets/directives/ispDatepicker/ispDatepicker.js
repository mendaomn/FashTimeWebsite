(function() {

    'use strict';

    var ispDatepicker = angular.module('ispDatepicker', ['ui.bootstrap']);

    ispDatepicker.directive('ispDatepicker', [function() {

        return {
            templateUrl: 'assets/directives/ispDatepicker/ispDatepicker.tpl.html',
            scope: {
                date: '=',
                label: '@',
                inputId: '@',
                inputName: '@',
                inputRequired: '=?',
                validationEvent: '@?',
                errorMessage: '@'
            },

            controller: function($scope, $rootScope, $timeout, $attrs) {

                $rootScope.scopes.push({ id: $scope.inputId, scope: $scope });

                $scope.opened = false;
                $scope.invalidDate = false;

                if ($attrs.hasOwnProperty('onlyValid')) {
                    $scope.onlyValid = true;
                }

                $scope.dateOptions = {
                    startingDay: 0,
                    showWeeks: false
                };

                $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'dd.MM.yyyy', 'shortDate'];
                $scope.format = $scope.formats[3];
                $scope.altInputFormats = ['M!/d!/yyyy'];

                $scope.open = function() {
                    $scope.opened = true;
                };

                $scope.today = function() {

                    $scope.dt = new Date();

                    $scope.date = {};
                    $scope.date.day = $scope.dt.getDate();
                    $scope.date.month = $scope.dt.getMonth();
                    $scope.date.year = $scope.dt.getFullYear();
                };

                $scope.setDate = function(date) {
                    $scope.dt = date;
                };

                $scope.$watch('date', function(newValue, oldValue) {

                    if (newValue && !angular.equals(newValue, oldValue)) {
                        $scope.setDate(new Date($scope.date.year, $scope.date.month, $scope.date.day));
                    }

                }, true);

                $scope.onDateChange = function() {

                    $scope.invalidDate = false;
                    $scope.serviceInvalidInput = false;

                    // ie11 aspect bug fix on input
                    var daypicker = document.getElementsByClassName('uib-daypicker')[0];
                    var datepickerPopup = document.getElementsByClassName('uib-datepicker-popup')[0];

                    if (daypicker && datepickerPopup) {
                        datepickerPopup.style.width = daypicker.clientWidth + "px";
                    }
                    //

                    if (!$scope.validationEvent) {
                        checkValidity();
                    }
                };

                var checkValidity = function() {

                    if ($scope.dt) {

                        $scope.invalidDate = false;

                        $scope.date = {};
                        $scope.date.day = $scope.dt.getDate();
                        $scope.date.month = $scope.dt.getMonth();
                        $scope.date.year = $scope.dt.getFullYear();

                    } else {

                        $scope.invalidDate = true;
                        $scope.date = null;
                    }
                };



                if ($scope.date) {
                    $scope.setDate(new Date($scope.date.year, $scope.date.month, $scope.date.day));
                } else {
                    $scope.today();
                }

                if ($scope.validationEvent) {

                    $scope.$on($scope.validationEvent, function() {
                        checkValidity();
                    });
                }
            }
        };
    }]);

})();