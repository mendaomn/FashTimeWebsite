(function() {

    'use strict';

    angular
    .module('ispCommunicationManager', [])
    .service('ispCommunicationManager', function($http, $log, $q) {

        this.callService = function(request) {

            var start = new Date().getTime();
            var end = null;
            var execTime = null;

            $http({
                url: request.name,
                method: request.method,
                headers: request.headers,
                params: request.params,
                timeout: request.timeout,
                data: request.input,
                responseType: request.responseType
            })

            .then(function(response) {

                end = new Date().getTime();
                execTime = end - start;

                response.execTime = execTime;

                request.callback(response);
            
            }, function(response) {
                
                $log.error(response);

                request.errorHandler();
            });
        };

        this.returnPromise = function(request) {

            var start = new Date().getTime();
            var end = null;
            var execTime = null;

            var deferred = $q.defer();

            $http({
                url: request.name,
                method: request.method,
                headers: request.headers,
                params: request.params,
                timeout: request.timeout,
                data: request.input,
                responseType: request.responseType
            })

            .then(function(response) {

                end = new Date().getTime();
                execTime = end - start;

                response.execTime = execTime;

                deferred.resolve(response);
            
            }, function(response) {
                
                $log.error(response);

                deferred.reject(response);
            });   

            return deferred.promise;
        };
    });
    
})();