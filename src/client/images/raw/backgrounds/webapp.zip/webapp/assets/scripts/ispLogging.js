(function() {

    'use strict';

    angular
        .module('ispLogging', [])
        .service('ispLogging', ['$http', function($http) {

            var logger = log4javascript.getLogger('isp-logging');
            var loggingLayout = new log4javascript.JsonLayout(true);

            var ajaxAppender;
            var loggingServiceUrl;

            var log = function(level, message) {

                if (!loggingServiceUrl) {
                    console.error('Please, set a Logging Service URL');
                    return;
                }

                ajaxAppender = new log4javascript.AjaxAppender(loggingServiceUrl);
                ajaxAppender.setLayout(loggingLayout);
                ajaxAppender.addHeader("Content-Type", "application/json");
                ajaxAppender.setThreshold(log4javascript.Level[level.toUpperCase()]);

                logger.setLevel(log4javascript.Level[level.toUpperCase()]);
                logger.addAppender(ajaxAppender);
                logger[level](message);
            };

            this.setUrl = function(url) {
                loggingServiceUrl = url;
            };

            this.fatal = function(message) {
                log('fatal', message);
            };

            this.error = function(message) {
                log('error', message);
            };

            this.warn = function(message) {
                log('warn', message);
            };

            this.info = function(message) {
                log('info', message);
            };

            this.debug = function(message) {
                log('debug', message);
            };

            this.trace = function(message) {
                log('trace', message);
            };
        }]);

})();