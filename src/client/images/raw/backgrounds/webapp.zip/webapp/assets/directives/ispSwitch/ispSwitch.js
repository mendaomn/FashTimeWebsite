(function() {

    'use strict';

    var ispSwitch = angular.module('ispSwitch', []);

    ispSwitch.directive('ispSwitch', [function() {

        return {
            templateUrl: 'assets/directives/ispSwitch/ispSwitch.tpl.html',
            scope: {
                choices: '=',
                type: '@',
                clickFn: '&',
                disabled: '=',
                selected: '=',
                textUp: '='
            },

            controller: function($scope) {

                if (!$scope.selected) {
                    $scope.selected = 0;
                }

                $scope.onSelect = function(choice) {

                    $scope.selected = choice;

                    setTimeout(function() {
                        $scope.clickFn();
                    });
                }
            }
        };
    }]);

})();