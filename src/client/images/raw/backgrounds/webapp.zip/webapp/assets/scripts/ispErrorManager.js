(function() {

    'use strict';

    var ispErrorManager = angular.module('ispErrorManager', []);

    ispErrorManager.service('ispErrorManager', function($rootScope) {

        var self = this;

        self.genericErrorCodes = null;
        self.specificErrorCodes = null;
        self.genericErrorCallback = null;

        self.setGenericErrorCodes = function(codes) {
            self.genericErrorCodes = codes;
        };

        self.setSpecificErrorCodes = function(codes) {
            self.specificErrorCodes = codes;
        };

        self.setGenericErrorCallback = function(callback) {
            self.genericErrorCallback = callback;
        };

        self.manageError = function(data) {

            if (!self.genericErrorCodes) {
                console.error("ISP Error Manager - No generic error codes defined.");
                return;
            }

            if (!self.specificErrorCodes) {
                console.error("ISP Error Manager - No specific error codes defined.");
                return;
            }

            if (!self.genericErrorCallback) {
                console.error("ISP Error Manager - No generic error callback function defined.");
                return;
            }

            if (!data) {
                console.error("ISP Error Manager - No data.");
                return;
            }

            if (self.genericErrorCodes.indexOf(data.esito.returnCode) > -1) {
                self.genericErrorCallback(data.esito.messages[0]);
            }

            if (self.specificErrorCodes.indexOf(data.esito.returnCode) > -1) {

                for (var i = 0; i < data.esito.messages.length; i++) {

                    for (var j = 0; j < $rootScope.scopes.length; j++) {

                        if ($rootScope.scopes[j].id.toString() === data.esito.messages[i].code) {

                            $rootScope.scopes[j].scope.serviceErrorMessage = data.esito.messages[i].description;
                            $rootScope.scopes[j].scope.serviceInvalidInput = true;
                            $rootScope.scopes[j].scope.invalidInput = false;
                        }
                    }
                }

            } else {

                console.error("ISP Error Manager - Unknown returned code.");
                return;
            }
        };

    });

})();