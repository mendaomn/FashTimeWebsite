(function() {

    'use strict';

    var ispLabel = angular.module('ispLabel', []);

    ispLabel.directive('ispLabel', [function() {

        return {
            templateUrl: 'assets/directives/ispLabel/ispLabel.tpl.html',
            scope: {
                data: '@',
                required: '=',
                target: '@?'
            }
        };

    }]);

})();