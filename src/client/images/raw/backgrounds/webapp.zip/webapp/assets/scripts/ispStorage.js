(function() {

    'use strict';

    angular
    .module('ispStorage', [])
    .service('ispStorage', function($window) {

        /* session */
        this.setSession = function(key, value) {
            $window.sessionStorage.setItem(key, angular.toJson(value));
        };

        this.getSession = function(key) {
            
            if ($window.sessionStorage[key]) {
                return angular.fromJson($window.sessionStorage[key]);
            }

            return {};
        };

        this.removeSession = function(key) {

            if ($window.sessionStorage[key]) {
                $window.sessionStorage.removeItem(key);
            }
        };

        this.clearSession = function() {

            for (var i = 0; i < $window.sessionStorage.length; i++) {
                $window.sessionStorage.removeItem($window.sessionStorage.key(i));
            }
        };

        this.newSessionStorage = function() {

            return {
                set: this.setSession,
                get: this.getSession,
                remove: this.removeSession,
                clear: this.clearSession
            }
        };

        /* local */
        this.setLocal = function(key, value) {
            $window.localStorage.setItem(key, angular.toJson(value));
        };

        this.getLocal = function(key) {

            if ($window.localStorage[key]) {
                return angular.fromJson($window.localStorage[key]);
            }

            return {};
        };

        this.removeLocal = function(key) {

            if ($window.localStorage[key]) {
                $window.localStorage.removeItem(key);
            }
        };

        this.clearLocal = function() {

            for (var i = 0; i < $window.localStorage.length; i++) {
                $window.localStorage.removeItem($window.localStorage.key(i));
            }
        };

        this.newLocalStorage = function() {

            return {
                set: this.setLocal,
                get: this.getLocal,
                remove: this.removeLocal,
                clear: this.clearLocal
            }
        };
    });
    
})();