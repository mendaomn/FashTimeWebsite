(function() {

    'use strict';

    var ispAccordion = angular.module('ispAccordion', ['ui.bootstrap']);

    ispAccordion.directive('ispAccordion', [function() {

        return {
            templateUrl: 'assets/directives/ispAccordion/ispAccordion.tpl.html',
            scope: {
                groups: '='
            }
        };
    }]);

    ispAccordion.directive('ispInnerAccordion', [function() {

        return {
            restrict: 'E',
            template: '<ng-include src="getContentUrl()"/>',
            scope: {
                content: '=',
                innerAccordionContents: '='
            },

            controller: function($scope) {

                $scope.getContentUrl = function() {
                    return $scope.content;
                };
            }
        };
    }]);

})();