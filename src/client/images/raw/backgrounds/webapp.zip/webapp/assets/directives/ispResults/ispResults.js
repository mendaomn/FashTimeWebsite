(function() {

    'use strict';

    var ispResults = angular.module('ispResults', ['ispCheckbox']);

    ispResults.directive('ispResults', [function() {

        return {
            templateUrl: 'assets/directives/ispResults/ispResults.tpl.html',
            scope: {
                labels: '=',
                results: '=',
                showCheckbox: '=',
                selectedResult: '=',
                selectedResults: '=',
                clickFn: '&'
            },

            controller: function($scope) {

                $scope.onClick = function(result) {

                    $scope.selectedResult = result;

                    setTimeout(function() {
                        $scope.clickFn();
                    });
                }

                $scope.selectResult = function(result, hashKey) {

                    if (result.selected) {

                        $scope.selectedResults.push(result);

                    } else {

                        $scope.selectedResults = $scope.selectedResults.filter(function(item) {
                            return item.$$hashKey !== hashKey;
                        });
                    }
                }
            }
        };
    }]);

})();