(function() {

    'use strict';

    var ispTab = angular.module('ispTab', []);

    ispTab.directive('ispTab', [function() {

        return {
            templateUrl: 'assets/directives/ispTab/ispTab.tpl.html',
            scope: {
                tabs: '='
            },

            controller: function($scope) {

                $scope.selectedContent = $scope.tabs[0].content;

                $scope.selectTab = function(index) {

                    if (!$scope.tabs[index].disabled) {

                        for (var i = 0; i < $scope.tabs.length; i++) {
                            $scope.tabs[i].selected = false;
                        }

                        $scope.tabs[index].selected = true;
                        $scope.selectedContent = $scope.tabs[index].content;
                    }
                };

            }
        };
    }]);

})();