(function() {

    'use strict';

    var ispRadio = angular.module('ispRadio', []);

    ispRadio.directive('ispRadio', [function() {

        return {
            templateUrl: 'assets/directives/ispRadio/ispRadio.tpl.html',
            scope: {
                data: '=',
                value: '=',
                radioId: '@?',
                label: '@',
                disabled: '=',
            },

            controller: function($scope, $attrs) {

                if ($attrs.displayInline === '') {
                    $scope.displayInline = true;
                }

                $scope.onSelect = function() {

                    if (!$scope.selected) {
                        $scope.selected = true;
                        $scope.data = $scope.value;
                    }
                }

                $scope.$watch('data', function() {

                    if ($scope.data !== $scope.value) {
                        $scope.selected = false;
                    } else {
                        $scope.selected = true;
                    }
                });
            }
        };
    }]);

})();