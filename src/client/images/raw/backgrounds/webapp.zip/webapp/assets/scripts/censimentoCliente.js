(function() {

    'use strict';

    angular

    .module('censimentoCliente', ['ispCommunicationManager', 'ispServiceRequest'])

    .controller('CensimentoClienteCtrl', function($scope, $rootScope, $state, $timeout, ispCommunicationManager, ispServiceRequest, ispStorage) {

        $rootScope.pageTitle = 'CENSIMENTO CLIENTE';

        $scope.datiCliente = $rootScope.sessionStorage.get('datiCliente');

        $scope.paesi = [{
            name: 'Italia',
            value: '0'
        }, {
            name: 'Germania',
            value: '1'
        }, {
            name: 'Francia',
            value: '2'
        }, {
            name: 'Finlandia',
            value: '3'
        }, {
            name: 'Spagna',
            value: '4'
        }, {
            name: 'Svizzera',
            value: '5'
        }];

        $scope.tipologieLavoro = [{
            name: 'Impiegato',
            value: '0'
        }, {
            name: 'Libero Professionista',
            value: '1'
        }, {
            name: 'Dipendente Statale',
            value: '2'
        }];

        $scope.openInfoModal = function(title, content) {
            $scope.infoModalOpened = true;
            $scope.infoModalTitle = title;
            $scope.infoModalData = content;
        };

        $scope.openEsitoModal = function(title, content) {
            $scope.esitoModalOpened = true;
            $scope.esitoModalTitle = title;
            $scope.esitoModalData = content;
        };

        $scope.requestGoBack = function() {
            $scope.openInfoModal('ATTENZIONE', 'Tornando alla Home, tutti i dati inseriti andranno persi. Continuare?');
        };

        $scope.confirmModalFn = function() {
            $scope.goToState('home');
        };

        $scope.goToState = function(state) {

            $rootScope.sessionStorage.set('datiCliente', $scope.datiCliente);
            $state.go(state);
        };

        $scope.callTestService = function(request, endpoint) {

            request = {
                "args0":"ciao",
                "args1": [128, 700],
                "args2": "http://saxstt712:9005/scriptNbpl0/atomicservices/EchoService",
                "args3": "http://saxstt712:9005/scriptNbpl0/atomicservices/CalcService"
            };

            var requestObject = {
                name: '/scriptNbpl0/pocfrontend/service/caller/exposedProcessesWSRR',
                method: 'post',
                input: request,
                
                callback: function(response) {
                    
                    console.log(request);
                    console.log(response);

                    if (response.data.esito.statoEsito) {
                        $scope.result = true;
                    } else {
                        $scope.result = false;
                    }
                    
                    $timeout(function() {

                        $rootScope.loading = false;
                        $scope.openEsitoModal('CENSIMENTO CLIENTE', 'Inserimento avvenuto con successo.');
                   
                   }, 500);
                },
                
                errorHandler: function() {
          
                    console.log('Si è verificato un errore.');
               
                    $scope.result = false;
                    
                    $timeout(function() {
                        
                        $rootScope.loading = false;
                        $scope.openEsitoModal('CENSIMENTO CLIENTE', 'Si è verificato un errore, non è stato possibile proseguire con l\'inserimento.');

                    }, 500);
                },
                
                timeout: null,
                headers: null,
                params: null,
                responseType: 'json'
            };

            $rootScope.loading = true;
            ispCommunicationManager.callService(ispServiceRequest.initObject(requestObject));
        };
    });

})();