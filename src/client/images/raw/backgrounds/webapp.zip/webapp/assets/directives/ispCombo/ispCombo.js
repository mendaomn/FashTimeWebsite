(function() {

    'use strict';

    var ispCombo = angular.module('ispCombo', []);

    ispCombo.directive('ispCombo', ['$document', function($document) {

        return {
            templateUrl: 'assets/directives/ispCombo/ispCombo.tpl.html',
            scope: {
                items: '=',
                label: '@',
                selectedItem: '=',
                itemLabel: '@',
                inputId: '@',
                inputName: '@',
                inputRequired: '=?',
                onSelectFn: '&?',
                validationEvent: '@?',
                placeholder: '@?',
                errorMessage: '@?',
                disabled: '=?'
            },

            controller: function($scope, $rootScope) {
                $rootScope.scopes.push({ id: $scope.inputId, scope: $scope });
            },

            link: function(scope, element) {

                var pressedCombo = false;

                scope.activeItemIndex = 0;
                scope.inputValue = '';
                scope.comboVisible = false;
                scope.comboItems = scope.items || [];
                scope.invalidInput = false;
                scope.serviceInvalidInput = false;

                scope.$watch('comboItems', function(newValue, oldValue) {

                    if (!angular.equals(newValue, oldValue)) {
                        scope.setActive(0);
                    }
                });

                scope.$watch('selectedItem', function(newValue, oldValue) {

                    scope.serviceInvalidInput = false;

                    if (!angular.equals(newValue, oldValue)) {

                        if (newValue) {

                            if (typeof newValue === 'string') {
                                scope.inputValue = newValue;
                            } else {
                                scope.inputValue = newValue[scope.itemLabel];
                            }
                        }
                    }
                });

                scope.setActive = function(itemIndex) {
                    scope.activeItemIndex = itemIndex;
                };

                scope.comboPressed = function() {
                    pressedCombo = true;
                }

                scope.selectItem = function(item) {

                    scope.selectedItem = item;

                    hideCombo();

                    scope.invalidInput = false;

                    if (scope.onSelectFn) {
                        scope.onSelectFn();
                    }
                };

                var findIndex = function(searchItem, items) {

                    var position = -1;

                    angular.forEach(items, function(item, index) {

                        if (typeof item === 'string') {

                            if (item === searchItem) {
                                position = index;
                            }

                        } else {

                            if (item[scope.itemLabel] === searchItem[scope.itemLabel]) {
                                position = index;
                            }
                        }
                    });

                    return position;
                }

                var hideCombo = function() {

                    scope.comboVisible = false;

                    if (scope.selectedItem) {
                        scope.setActive(findIndex(scope.selectedItem, scope.items));
                    }
                }

                var selectPreviousItem = function() {

                    var prevIndex = scope.activeItemIndex - 1;

                    if (prevIndex >= 0) {
                        scope.setActive(prevIndex);
                    }
                };

                var selectNextItem = function() {

                    var nextIndex = scope.activeItemIndex + 1;

                    if (nextIndex < scope.comboItems.length) {
                        scope.setActive(nextIndex);
                    }
                };

                var selectActiveItem = function() {

                    if (scope.activeItemIndex >= 0 && scope.activeItemIndex < scope.comboItems.length) {
                        scope.selectItem(scope.comboItems[scope.activeItemIndex]);
                    }
                };

                if (scope.selectedItem) {

                    scope.selectItem(scope.selectedItem);

                    scope.setActive(findIndex(scope.selectedItem, scope.items));

                    if (typeof scope.selectedItem === 'string') {
                        scope.inputValue = scope.selectedItem;
                    } else {
                        scope.inputValue = scope.selectedItem[scope.itemLabel];
                    }
                }

                element.bind("keydown keypress", function(event) {

                    switch (event.which) {

                        case 38:
                            scope.$apply(selectPreviousItem);
                            break;

                        case 40:
                            scope.$apply(selectNextItem);
                            break;

                        case 13:
                            if (scope.comboVisible && scope.comboItems && scope.comboItems.length > 0) {
                                event.preventDefault();
                                scope.$apply(selectActiveItem);
                            }
                            break;
                    }
                });

                var childElements = angular.element(element).find('*');

                angular.forEach(childElements, function(el, id) {
                    el.setAttribute('id', 'isp-' + scope.inputName + '-' + id);
                });

                $document.bind('click', function(event) {

                    var flag = false;

                    angular.forEach(childElements, function(el) {

                        if (event.target.id === el.id) {
                            flag = true;
                            return;
                        }
                    });

                    if (!flag && scope.comboVisible) {
                        event.preventDefault();
                        scope.$apply(hideCombo);
                    }
                });
            }
        };
    }]);

    ispCombo.directive('comboInputType', function() {
        return {
            require: 'ngModel',

            link: function(scope, element, attrs, ngModelController) {

                var setValid = function(field) {

                    field.$setValidity('parse', true);
                    scope.invalidInput = false;
                };

                var setInvalid = function(field) {

                    field.$setValidity('parse', false);
                    scope.invalidInput = true;
                };

                if (scope.validationEvent) {

                    scope.$on(scope.validationEvent, function() {

                        if (!scope.inputValue && scope.inputRequired) {

                            setInvalid(ngModelController);
                            return;
                        }

                        setValid(ngModelController);
                    });
                }
            }
        };
    });

})();