(function() {

    'use strict';

    var ispProgress = angular.module('ispProgress', []);

    ispProgress.directive('ispProgress', [function() {

        return {
            templateUrl: 'assets/directives/ispProgress/ispProgress.tpl.html',
            scope: {
                steps: "="
            },

            controller: function($scope, $rootScope, $state) {

                $scope.showProgress = true;

                var setCurrentStep = function(stepIndex) {

                    var i;

                    $scope.steps[stepIndex].active = true;

                    for (i = stepIndex - 1; i >= 0; i--) {
                        $scope.steps[i].active = false;
                        $scope.steps[i].value = 100;
                    }

                    for (i = stepIndex + 1; i < $scope.steps.length; i++) {
                        $scope.steps[i].active = false;
                        $scope.steps[i].value = 0;
                    }
                };

                var setCurrentPage = function(stepIndex, pageIndex) {

                    var i;

                    $scope.steps[stepIndex].value = (100 * pageIndex) / $scope.steps[stepIndex].pages.length;
                    $scope.steps[stepIndex].pages[pageIndex].status = 1;

                    for (i = pageIndex - 1; i >= 0; i--) {
                        $scope.steps[stepIndex].pages[i].status = 2;
                    }

                    for (i = pageIndex + 1; i < $scope.steps[stepIndex].pages.length; i++) {
                        $scope.steps[stepIndex].pages[i].status = 0;
                    }
                };

                $rootScope.$on('stateChangeSuccess', function(event, data) {

                    for (var i = 0; i < $scope.steps.length; i++) {

                        if ($state.current.data && $state.current.data.workflowStepName) {

                            if ($state.current.data.workflowStepName !== $scope.steps[i].name) {

                                for (var j = 0; j < $scope.steps[i].pages.length; j++) {

                                    if ($state.current.data.workflowStepName === $scope.steps[i].pages[j].name) {

                                        setCurrentStep(i);
                                        setCurrentPage(i, j);

                                        $scope.showProgress = true;

                                        return;
                                    }
                                }

                            } else {

                                setCurrentStep(i);

                                $scope.showProgress = true;
                            }
                        }

                        $scope.steps[i].active = false;
                        $scope.steps[i].value = 0;

                        $scope.showProgress = false;
                    }

                });

                $scope.width = 'col-xs-8';
                $scope.offset = 'col-xs-offset-0';

                $scope.$watch('steps', function() {

                    if ($scope.steps) {

                        switch ($scope.steps.length) {

                            case 2:
                                $scope.width = 'col-xs-8';
                                $scope.offset = 'col-xs-offset-4 col-md-offset-8';
                                break;

                            case 3:
                                $scope.width = 'col-xs-8';
                                $scope.offset = 'col-xs-offset-0 col-md-offset-6';
                                break;

                            case 4:
                                $scope.width = 'col-xs-6';
                                $scope.offset = 'col-xs-offset-0 col-md-offset-4';
                                break;

                            case 5:
                                $scope.width = 'col-xs-4';
                                $scope.offset = 'col-xs-offset-2';
                                break;

                            default:
                                $scope.width = 'col-xs-8';
                                $scope.offset = 'col-xs-offset-0';
                                break;
                        }
                    }
                });
            }
        };
    }]);

})();
