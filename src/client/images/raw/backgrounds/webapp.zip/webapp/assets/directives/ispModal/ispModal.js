(function() {

    'use strict';

    var ispModal = angular.module('ispModal', ['ui.bootstrap', 'ispButton', 'ngFileUpload']);

    ispModal.directive('ispModal', [function() {

        return {
            templateUrl: 'assets/directives/ispModal/ispModal.tpl.html',
            scope: {
                type: '@',
                opened: '=',
                title: '@?',
                data: '=?',
                result: '=?',
                confirmFn: '&?',
                confirmLabel: '@?',
                cancelFn: '&?',
                cancelLabel: '@?',
                uploadServiceUrl: '=?',
                uploadCompleteFn: '&?'
            },

            controller: function($scope, $attrs, $uibModal, Upload) {

                $scope.files = [];

                $scope.animationEnabled = true;

                if ('multipleFiles' in $attrs) {
                    $scope.multipleFiles = true;
                }

                if ('disableAnimation' in $attrs) {
                    $scope.animationEnabled = false;
                }

                var modalInstance = null;
                var size = '';

                switch ($scope.type) {

                    case 'info':
                        $scope.templateUrl = 'infoModal.html';
                        size = 'lg';
                        break;

                    case 'esito':
                        $scope.templateUrl = 'esitoModal.html';
                        size = 'lg';
                        break;

                    case 'upload':
                        $scope.templateUrl = 'uploadModal.html';
                        size = 'lg';
                        break;

                    default:
                        $scope.templateUrl = 'infoModal.html';
                        break;
                }

                $scope.onFilesChange = function(files) {
                    $scope.files = files;
                };

                $scope.removeFile = function(files, index) {
                    files.splice(index, 1);
                };

                $scope.$watch('opened', function() {

                    if ($scope.opened) {

                        $scope.files = [];

                        modalInstance = $uibModal.open({
                            animation: $scope.animationEnabled,
                            templateUrl: $scope.templateUrl,
                            size: size,
                            scope: $scope
                        });

                        modalInstance.result.then(null, function() {
                            $scope.opened = false;
                        });
                    }
                });

                $scope.ok = function() {

                    $scope.opened = !modalInstance.close();

                    if ($scope.confirmFn) {
                        $scope.confirmFn();
                    }
                };

                $scope.upload = function() {

                    Upload.upload({

                        url: $scope.uploadServiceUrl,
                        data: { file: $scope.files }

                    }).then(function(resp) {

                        if ($scope.uploadCompleteFn) {
                            $scope.uploadCompleteFn();
                        }

                        console.log('Upload complete.');

                    }, function(resp) {
                        console.log('Error status: ' + resp.status);
                    });
                };

                $scope.cancel = function() {

                    $scope.opened = !modalInstance.dismiss('cancel');

                    if ($scope.cancelFn) {
                        $scope.cancelFn();
                    }
                };
            }
        };
    }]);

})();