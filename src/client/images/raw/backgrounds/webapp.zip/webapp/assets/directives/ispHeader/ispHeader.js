(function() {

    'use strict';

    var ispHeader = angular.module('ispHeader', ['ispProgress', 'ispPaging']);

    ispHeader.directive('ispHeader', ['$rootScope', function($rootScope) {

        return {
            templateUrl: 'assets/directives/ispHeader/ispHeader.tpl.html',
            scope: {
                pageTitle: "=",
                pageSubtitle: "=",
                workflowSteps: "=?"
            },

            controller: function($scope, $rootScope, $timeout) {

                $scope.activeStep = {};
                $scope.menuOpen = false;

                var top = 0;

                window.scrollTo(0, 0);

                $scope.$watch('workflowSteps', function() {

                    if ($scope.workflowSteps) {

                        for (var i = 0; i < $scope.workflowSteps.length; i++) {

                            if ($scope.workflowSteps[i].active) {
                                $scope.activeStep = $scope.workflowSteps[i];
                                return;
                            }

                            $scope.activeStep = {};
                        }
                    }

                }, true);

                $scope.openCloseMenu = function() {

                    var navBar = document.getElementById('main-header');

                    if (navBar && !$scope.menuOpen) {
                        top = navBar.style.top;
                    }

                    $scope.menuOpen = !$scope.menuOpen;

                    if (navBar && $scope.menuOpen) {
                        navBar.style.top = "0px";
                    }

                    if (navBar && !$scope.menuOpen) {
                        navBar.style.top = top;
                    }

                    $rootScope.$broadcast("openCloseMenu", $scope.menuOpen);
                };

                window.onscroll = function() {

                    var navBar = document.getElementById('main-header');
                    var headerOverlay = document.getElementById('header-overlay');

                    if (navBar && headerOverlay && !$scope.menuOpen) {

                        headerOverlay.style.marginTop = this.pageYOffset <= 40 ? "-" + this.pageYOffset.toString() + "px" : "-40px";

                        if (this.pageYOffset <= 40) {
                            navBar.style.top = "0px";
                        }

                        if (this.pageYOffset > 40 && this.pageYOffset <= 110) {
                            navBar.style.top = "-" + (this.pageYOffset - 40).toString() + "px";
                        }

                        if (this.pageYOffset >= 110) {
                            navBar.style.top = "-70px";
                        }
                    }
                };
            }

        };
    }]);

})();