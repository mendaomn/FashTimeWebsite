(function() {

    'use strict';

    var ispPaging = angular.module('ispPaging', []);

    ispPaging.directive('ispPaging', [function() {

        return {
            templateUrl: 'assets/directives/ispPaging/ispPaging.tpl.html',
            scope: {
                pages: '='
            }
        };
    }]);

})();