(function() {

    'use strict';

    var ispProfileManager = angular.module('ispProfileManager', ['ispCommunicationManager', 'ispServiceRequest', 'ispServiceResponse']);

    ispProfileManager.constant('CONFIG', {
        SERVICE_URL: 'url/servizio/profilazione',
        OBSERVER_PARAMS: {
            childList: true,
            subtree: true
        }
    });

    ispProfileManager.service('ispAuthorization', function($compile, $rootScope, ispCommunicationManager, ispServiceRequest, ispServiceResponse, CONFIG) {

        var self = this;

        self.start = function(element) {

            var observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    self.get(element, CONFIG.SERVICE_URL);
                });
            });

            observer.observe(angular.element(element)[0], CONFIG.OBSERVER_PARAMS);
        };

        self.search = function(array, key) {

            for (var i = 0; i < array.length; i++) {
                if (array[i].key === key) {
                    return true;
                }
            }

            return false;
        };

        self.get = function(element, url) {

            var childElements = [],
                keys = [],
                request = {},
                change = false;

            if (!$rootScope.authElements) {
                $rootScope.authElements = [];
            };

            if (element.attr('key')) {

                if (!self.search($rootScope.authElements, element.attr('key'))) {

                    $rootScope.authElements.push({
                        element: element,
                        key: element.attr('key'),
                        auth: element.attr('auth')
                    });

                    change = true;
                }
            }

            childElements = element.find('*');

            [].forEach.call(childElements, function(element) {

                if (element.hasAttribute('key')) {

                    if (!self.search($rootScope.authElements, element.getAttribute('key'))) {

                        $rootScope.authElements.push({
                            element: element,
                            key: element.getAttribute('key'),
                            auth: element.getAttribute('auth')
                        });

                        change = true;
                    }
                }
            });

            if (change) {

                for (var i = 0; i < $rootScope.authElements.length; i++) {
                    keys.push({
                        key: $rootScope.authElements[i].key
                    });
                }

                request = {
                    name: url,
                    method: 'post',
                    input: keys,
                    callback: self.set,
                    errorHandler: self.errorHandler,
                    timeout: null,
                    headers: null,
                    params: null,
                    responseType: 'json'
                };

                ispCommunicationManager.callService(ispServiceRequest.initObject(request));
            }
        };

        self.set = function(authorizations) {

            if (authorizations) {

                for (var i = 0; i < authorizations.length; i++) {

                    for (var j = 0; j < $rootScope.authElements.length; j++) {

                        if (authorizations[i].key === $rootScope.authElements[j].key &&
                            authorizations[i].auth !== $rootScope.authElements[j].auth) {

                            $rootScope.authElements[j].auth = authorizations[i].auth;

                            var el = angular.element($rootScope.authElements[j].element);

                            el.attr('ng-show', authorizations[i].auth);
                            el.attr('auth', authorizations[i].auth);

                            el.removeAttr('authorize');

                            if (el.attr('ng-repeat')) {

                                el.removeAttr('ng-repeat');
                                el.removeAttr('isp-repeat');

                                for (var k = 0; k < $rootScope.scopes.length; k++) {

                                    if ($rootScope.scopes[k].id.toString() === el.attr('id')) {
                                        $compile(el)($rootScope.scopes[k].scope);
                                    }
                                }

                            } else {

                                $compile(el)($scope);
                            }
                        }
                    }
                }
            }
        };

        self.errorHandler = function() {

            /* MOCK */
            var authorizations = [{
                key: 'i1',
                auth: true
            }, {
                key: 'b1',
                auth: true
            }, {
                key: 'b2',
                auth: false
            }, {
                key: 'b3',
                auth: true
            }, {
                key: 'b4',
                auth: true
            }, {
                key: 'b5',
                auth: true
            }, {
                key: 'b6',
                auth: true
            }, {
                key: 'b7',
                auth: false
            }, {
                key: 'b8',
                auth: true
            }, {
                key: 'b9',
                auth: true
            }, {
                key: 'h1',
                auth: true
            }];

            self.set(authorizations);
            /* END MOCK */

            console.log("Get authorizations error.");
        };
    });

    ispProfileManager.directive('authorize', ['ispAuthorization', function(ispAuthorization) {

        return {
            restrict: 'A',

            controller: function($element, ispAuthorization) {

                ispAuthorization.start(angular.element($element));
            }
        };
    }]);

    ispProfileManager.directive('ispRepeat', [function() {

        return {

            controller: function($scope, $rootScope, $element) {

                var el = angular.element($element);
                el.attr('id', $scope.$id);

                $rootScope.scopes.push({ id: $scope.$id, scope: $scope });
            }
        };
    }]);

})();