(function() {

    'use strict';

    angular
    .module('test', [])
    .controller('TestCtrl', function($scope, $rootScope, ispCommunicationManager, ispServiceRequest) {

        // header example
        $rootScope.pageTitle = 'DEMO';
        $rootScope.pageSubtitle = 'Demo';

        var successCallback = function(response) {
            $rootScope.loading = false;
            $scope.testResponse = JSON.stringify(response);
        };

        var errorCallback = function(response) {
            $rootScope.loading = false;
            $scope.testResponse = 'Si è verificato un errore: ' + response.status + ' (' + response.statusText + ')';
        };

        // communication manager example
        $scope.callTestService = function(request, endpoint) {

            var requestObject = {
                name: endpoint,
                method: 'post',
                input: request,
                callback: successCallback,
                errorHandler: errorCallback,
                timeout: null,
                headers: null,
                params: null,
                responseType: 'json'
            };

            $rootScope.loading = true;

            var promise = ispCommunicationManager.returnPromise(ispServiceRequest.initObject(requestObject));

            promise.then(function(response){
                requestObject.callback(response);
            }, function(response) {
                requestObject.errorHandler(response);
            });
        };

    });

})();