(function() {

    'use strict';

    var ispFooter = angular.module('ispFooter', ['ui.router', 'ispButton']);

    ispFooter.directive('ispFooter', ['$state', function($state) {

        return {
            templateUrl: 'assets/directives/ispFooter/ispFooter.tpl.html',
            scope: {
                links: '=',
                centralBtn: '=',
                showCentralBtn: '@?'
            },

            controller: function($scope, $location, $window) {

                if (!$scope.showCentralBtn) {
                    $scope.showCentralBtn = true;
                }

                if (!$scope.zoomSize) {
                    $scope.zoomSize = 25;
                }

                $scope.contrasto = 1;
                $scope.testo = 2;

                $scope.setZoom = function(value) {

                    $scope.testo = value;

                    if (value === 1) {
                        document.body.style.fontSize = "12px";
                        return;
                    }

                    if (value === 2) {
                        document.body.style.fontSize = "16px";
                        return;
                    }

                    if (value === 3) {
                        document.body.style.fontSize = "20px";
                        return;
                    }
                };

                $scope.redirectTo = function(link) {

                    if (link.internalState) {

                        var states = $state.get();

                        for (var i = 0; i < states.length; i++) {

                            if (states[i].name === link.url) {

                                $location.path(link.url);
                                $state.go(link.url);

                                return;
                            }
                        }

                        console.log('Stato non definito');

                    } else {

                        if (link.url.search('http://') > -1) {
                            $window.open(link.url, "_blank");
                        } else {
                            $window.open('http://' + link.url, "_blank");
                        }
                    }
                };
            }
        };
    }]);

})();