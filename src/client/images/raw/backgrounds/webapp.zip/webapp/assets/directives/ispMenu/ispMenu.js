(function() {

    'use strict';

    var ispMenu = angular.module('ispMenu', ['ispProfileManager']);

    ispMenu.directive('ispMenu', [function() {

        return {
            templateUrl: 'assets/directives/ispMenu/ispMenu.tpl.html',
            scope: {
                menu: '=',
                onClickFn: '&?'
            },

            controller: function($scope, $location, $timeout) {

                $scope.isOpen = false;
                $scope.selected = {};
                $scope.showSecondLevelMenu = false;

                $scope.$on("openCloseMenu", function(event, data) {
                    $scope.isOpen = data;
                });

                $scope.goBack = function() {
                    $scope.selected = {};
                    $scope.showSecondLevelMenu = false;
                };

                $scope.onClick = function(button) {

                    if (button.secondLevel) {
                        $scope.selected = button;
                        return;
                    }

                    if ($scope.onClickFn) {
                        $scope.onClickFn();
                    }

                    $location.path(button.url);
                };

                $scope.showSecondLevel = function() {
                    $timeout(function() {
                        $scope.showSecondLevelMenu = true;
                        document.getElementsByClassName('menu')[0].scrollTop = 0;
                    });
                };
            }
        };
    }]);

})();