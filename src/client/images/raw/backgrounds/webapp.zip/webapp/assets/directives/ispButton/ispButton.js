(function() {

    'use strict';

    var ispButton = angular.module('ispButton', []);

    ispButton.directive('ispButton', [function() {

        return {
            templateUrl: 'assets/directives/ispButton/ispButton.tpl.html',
            scope: {
                label: '@',
                clickFn: '&',
                icon: '@',
                disabled: '='
            },

            link: function(scope, element, attrs) {

                if ("default" in attrs) {
                    scope.isDefault = true;
                }
            }
        };
    }]);

})();