(function() {

    'use strict';

    var ispDropdown = angular.module('ispDropdown', []);

    ispDropdown.directive('ispDropdown', ['$q', '$document', function($q, $document) {

        return {
            templateUrl: 'assets/directives/ispDropdown/ispDropdown.tpl.html',
            scope: {
                items: '=',
                type: '@?',
                label: '@',
                selectedItem: '=',
                inputId: '@',
                inputName: '@',
                inputRequired: '=?',
                inputDisabled: '=?',
                onFocusFn: '&?',
                onBlurFn: '&?',
                onChangeFn: '&?',
                onSelectFn: '&?',
                validationEvent: '@?',
                placeholder: '@?',
                errorMessage: '@?'
            },

            controller: function($scope, $rootScope, $attrs) {

                $rootScope.scopes.push({ id: $scope.inputId, scope: $scope });

                $scope.onlyValid = false;
                $scope.serviceInvalidInput = false;

                if ($attrs.hasOwnProperty('onlyValid')) {
                    $scope.onlyValid = true;
                }
            },

            link: function(scope, element) {

                var pressedDropdown = false;

                scope.activeItemIndex = 0;
                scope.inputValue = '';
                scope.dropdownVisible = false;
                scope.dropdownItems = scope.items || [];
                scope.invalidInput = false;
                scope.serviceInvalidInput = false;

                scope.$watch('dropdownItems', function(newValue, oldValue) {

                    if (!angular.equals(newValue, oldValue)) {
                        scope.setActive(0);
                    }
                });

                scope.$watch('selectedItem', function(newValue, oldValue) {

                    scope.serviceInvalidInput = false;

                    if (!angular.equals(newValue, oldValue)) {

                        if (newValue) {

                            if (typeof newValue === 'string') {
                                scope.inputValue = newValue;
                            } else {
                                scope.inputValue = newValue.name;
                            }
                        }
                    }
                });

                scope.setActive = function(itemIndex) {
                    scope.activeItemIndex = itemIndex;
                };

                scope.inputChange = function(inputValue) {

                    scope.serviceInvalidInput = false;

                    scope.selectedItem = null;

                    showDropdown();

                    if (!inputValue) {

                        scope.dropdownItems = scope.items || [];
                        return;

                    } else {
                        scope.invalidInput = false;
                    }

                    var promise = scope.filterObjectList(inputValue);

                    if (promise) {

                        promise.then(function(dropdownItems) {

                            scope.dropdownItems = dropdownItems;

                            if (scope.dropdownItems.length === 0) {
                                hideDropdown();
                            }
                        });
                    }

                    if (scope.onChangeFn) {
                        scope.onChangeFn();
                    }
                };

                scope.filterObjectList = function(userInput) {

                    var filter = $q.defer();
                    var normalisedInput = userInput.toLowerCase();

                    var filteredArray = scope.items.filter(function(item) {
                        var matchName = item.name.toLowerCase().search(normalisedInput) > -1;
                        return matchName;
                    });

                    filter.resolve(filteredArray);

                    return filter.promise;
                };

                scope.searchInput = function(userInput) {

                    if (userInput) {

                        var filter = $q.defer();
                        var normalisedInput = userInput.toLowerCase();

                        var filteredArray = scope.items.filter(function(item) {
                            var matchName = item.name.toLowerCase() === normalisedInput;
                            return matchName;
                        });

                        if (filteredArray.length > 0) {
                            return true;
                        } else {
                            return false;
                        }
                    }
                }

                scope.inputFocus = function() {

                    scope.setActive(0);

                    if (scope.dropdownItems.length > 0) {
                        showDropdown();
                    }

                    if (scope.onFocusFn) {
                        scope.onFocusFn();
                    }
                };

                scope.inputBlur = function(event) {

                    if (pressedDropdown) {
                        pressedDropdown = false;
                        return;
                    }

                    hideDropdown();

                    if (!scope.validationEvent) {
                        if (scope.inputRequired && (scope.dropdownItems.length === 0 || !scope.inputValue || !scope.searchInput(scope.inputValue))) {
                            scope.invalidInput = true;
                        } else {
                            scope.invalidInput = false;
                        }
                    }

                    if (scope.searchInput(scope.inputValue)) {
                        scope.selectItem(scope.dropdownItems[0]);
                    }

                    if (scope.onBlurFn) {
                        scope.onBlurFn();
                    }
                };

                scope.dropdownPressed = function() {
                    pressedDropdown = true;
                }

                scope.selectItem = function(item) {

                    scope.selectedItem = item;

                    hideDropdown();

                    scope.dropdownItems = [item];

                    scope.invalidInput = false;

                    if (scope.onSelectFn) {
                        scope.onSelectFn();
                    }
                };

                var showDropdown = function() {

                    if (scope.dropdownItems.length > 0) {
                        scope.dropdownVisible = true;
                    }
                };

                var hideDropdown = function() {
                    scope.dropdownVisible = false;
                }

                var selectPreviousItem = function() {

                    var prevIndex = scope.activeItemIndex - 1;

                    if (prevIndex >= 0) {
                        scope.setActive(prevIndex);
                    }
                };

                var selectNextItem = function() {

                    var nextIndex = scope.activeItemIndex + 1;

                    if (nextIndex < scope.dropdownItems.length) {
                        scope.setActive(nextIndex);
                    }
                };

                var selectActiveItem = function() {

                    if (scope.activeItemIndex >= 0 && scope.activeItemIndex < scope.dropdownItems.length) {
                        scope.selectItem(scope.dropdownItems[scope.activeItemIndex]);
                    }
                };

                if (scope.selectedItem) {

                    scope.selectItem(scope.selectedItem);

                    if (typeof scope.selectedItem === 'string') {
                        scope.inputValue = scope.selectedItem;
                    } else {
                        scope.inputValue = scope.selectedItem.name;
                    }
                }

                element.bind("keydown keypress", function(event) {

                    switch (event.which) {

                        case 38:
                            scope.$apply(selectPreviousItem);
                            break;

                        case 40:
                            scope.$apply(selectNextItem);
                            break;

                        case 13:
                            if (scope.dropdownVisible && scope.dropdownItems && scope.dropdownItems.length > 0) {
                                event.preventDefault();
                                scope.$apply(selectActiveItem);
                            }
                            break;
                    }
                });

                var childElements = angular.element(element).find('*');

                angular.forEach(childElements, function(el, id) {
                    el.setAttribute('id', 'isp-' + scope.inputName + '-' + id);
                });

                $document.bind('click', function(event) {

                    var flag = false;

                    angular.forEach(childElements, function(el) {

                        if (event.target.id === el.id) {
                            flag = true;
                            return;
                        }
                    });

                    if (!flag && scope.dropdownVisible) {
                        event.preventDefault();
                        scope.$apply(scope.inputBlur);
                    }
                });
            }
        };
    }]);

    ispDropdown.directive('dropdownInputType', function() {

        return {
            require: 'ngModel',

            link: function(scope, element, attrs, ngModelController) {

                var pattern;
                var lastValidValue;
                var lastCommittedValue;

                var NUMERIC_REGEXP = /^\d+$/;
                var ALPHA_REGEXP = /^[a-zA-Z\s\'\u00C0\u00C1\u00C8\u00C8\u00CC\u00D2\u00D3\u00D9\u00DA\u00E0\u00E1\u00E8\u00E9\u00EC\u00F2\u00F3\u00F9\u00FA]+$/;
                var ALPHANUMERIC_REGEXP = /^[\w\s\'\u00C0\u00C1\u00C8\u00C8\u00CC\u00D2\u00D3\u00D9\u00DA\u00E0\u00E1\u00E8\u00E9\u00EC\u00F2\u00F3\u00F9\u00FA]+$/;
                var CAP_REGEXP = /^\d{5}$/;
                var CURRENCY_REGEXP = /^\d+\,?\d{0,2}$/;
                var EMAIL_REGEXP = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                var PASSWORD_REGEXP = /./;
                var PHONENUMBER_REGEXP = /^(?:\+\d{1,3}|0\d{1,3}|00\d{1,2})?(?:[-\/\s.]|\d)+$/;



                var isCF = function(cf) {

                    var i, s, set1, set2, setpari, setdisp;

                    if (typeof cf === 'undefined' || cf === '') {
                        return false;
                    }

                    cf = cf.toUpperCase();

                    set1 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    set2 = "ABCDEFGHIJABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    setpari = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    setdisp = "BAKPLCQDREVOSFTGUHMINJWZYX";
                    s = 0;

                    for (i = 1; i <= 13; i += 2) {
                        s += setpari.indexOf(set2.charAt(set1.indexOf(cf.charAt(i))));
                    }

                    for (i = 0; i <= 14; i += 2) {
                        s += setdisp.indexOf(set2.charAt(set1.indexOf(cf.charAt(i))));
                    }

                    if (s % 26 !== cf.charCodeAt(15) - 'A'.charCodeAt(0)) {
                        return false;
                    }

                    return true;
                };

                var setValid = function(field) {

                    field.$setValidity('parse', true);
                    scope.invalidInput = false;
                };

                var setInvalid = function(field) {

                    field.$setValidity('parse', false);
                    scope.invalidInput = true;
                };

                var checkValidity = function() {

                    if (!ngModelController.$viewValue && scope.inputRequired) {

                        setInvalid(ngModelController);
                        return;
                    }

                    if (pattern.test(ngModelController.$viewValue)) {

                        if (scope.type === 'cf') {

                            if (isCF(ngModelController.$viewValue)) {

                                setValid(ngModelController);

                            } else {

                                setInvalid(ngModelController);
                            }

                        } else {

                            setValid(ngModelController);
                        }

                    } else {

                        setInvalid(ngModelController);
                    }
                };



                if (!ngModelController) {
                    return;
                }

                switch (scope.type) {

                    case 'numeric':
                        pattern = NUMERIC_REGEXP;
                        break;

                    case 'alpha':
                        pattern = ALPHA_REGEXP;
                        break;

                    case 'alphanumeric':
                        pattern = ALPHANUMERIC_REGEXP;
                        break;

                    case 'cap':
                        pattern = CAP_REGEXP;
                        break;

                    case 'cf':
                        pattern = ALPHANUMERIC_REGEXP;
                        break;

                    case 'currency':
                        pattern = CURRENCY_REGEXP;
                        break;

                    case 'email':
                        pattern = EMAIL_REGEXP;
                        break;

                    case 'tel':
                        pattern = PHONENUMBER_REGEXP;
                        break;

                    case 'pwd':
                        pattern = PASSWORD_REGEXP;
                        break;

                    default:
                        pattern = PASSWORD_REGEXP;
                        break;
                }

                ngModelController.$parsers.push(function(data) {

                    scope.invalidInput = false;
                    scope.serviceInvalidInput = false;

                    if (scope.onlyValid) {

                        if (data !== '' && !pattern.test(data)) {
                            data = lastValidValue;
                        }

                        lastValidValue = angular.copy(data);
                    }

                    if (scope.type === 'cf') {
                        data = data.toUpperCase();
                    }

                    ngModelController.$setViewValue(data);
                    ngModelController.$render();

                    if (!scope.validationEvent) {
                        checkValidity();
                    }

                    if (lastCommittedValue !== data) {
                        lastCommittedValue = data;
                        scope.inputChange(lastCommittedValue);
                    }

                    return data;
                });

                if (scope.validationEvent) {

                    scope.$on(scope.validationEvent, function() {
                        checkValidity();
                    });
                }
            }
        };
    });

})();