(function() {

    'use strict';

    var ispCheckbox = angular.module('ispCheckbox', []);

    ispCheckbox.directive('ispCheckbox', [function() {

        return {
            templateUrl: 'assets/directives/ispCheckbox/ispCheckbox.tpl.html',
            scope: {
                data: '=',
                checkboxId: '@?',
                label: '@',
                disabled: '='
            },
            controller: function($scope, $attrs) {

                if ($attrs.displayInline === '') {
                    $scope.displayInline = true;
                }
            }
        };
    }]);

})();