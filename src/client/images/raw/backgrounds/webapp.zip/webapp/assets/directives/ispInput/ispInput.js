(function() {

    'use strict';

    var ispInput = angular.module('ispInput', ['ispButton']);

    ispInput.directive('ispInput', [function() {

        return {
            templateUrl: 'assets/directives/ispInput/ispInput.tpl.html',
            scope: {
                inputId: '@',
                inputName: '@',
                data: '=',
                type: '@?',
                label: '@',
                maxLength: '@?',
                inputRequired: '=?',
                inputDisabled: '=?',
                onFocusFn: '&?',
                onBlurFn: '&?',
                onChangeFn: '&?',
                validationEvent: '@?',
                placeholder: '@?',
                errorMessage: '@?'
            },

            controller: function($scope, $rootScope, $attrs) {

                $rootScope.scopes.push({ id: $scope.inputId, scope: $scope });

                $scope.onlyValid = false;
                $scope.squaredBorder = false;
                $scope.invalidInput = false;
                $scope.serviceInvalidInput = false;

                if ($attrs.hasOwnProperty('onlyValid')) {
                    $scope.onlyValid = true;
                }

                if ($attrs.hasOwnProperty('squaredBorder')) {
                    $scope.squaredBorder = true;
                }
            }
        };
    }]);

    ispInput.directive('inputType', ['$timeout', function($timeout) {

        return {
            require: 'ngModel',

            link: function(scope, element, attrs, ngModelController) {

                var pattern;
                var lastValidValue;
                var lastCommittedValue;

                var NUMERIC_REGEXP = /^\d+$/;
                var ALPHA_REGEXP = /^[a-zA-Z\s\'\u00C0\u00C1\u00C8\u00C8\u00CC\u00D2\u00D3\u00D9\u00DA\u00E0\u00E1\u00E8\u00E9\u00EC\u00F2\u00F3\u00F9\u00FA]+$/;
                var ALPHANUMERIC_REGEXP = /^[\w\s\'\u00C0\u00C1\u00C8\u00C8\u00CC\u00D2\u00D3\u00D9\u00DA\u00E0\u00E1\u00E8\u00E9\u00EC\u00F2\u00F3\u00F9\u00FA]+$/;
                var CAP_REGEXP = /^\d{5}$/;
                var CURRENCY_REGEXP = /^\d+\,?\d{0,2}$/;
                var EMAIL_REGEXP = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
                var PASSWORD_REGEXP = /./;
                var PHONENUMBER_REGEXP = /^(?:\+\d{1,3}|0\d{1,3}|00\d{1,2})?(?:[-\/\s.]|\d)+$/;



                var isCF = function(cf) {

                    var i, s, set1, set2, setpari, setdisp;

                    if (typeof cf === 'undefined' || cf === '') {
                        return false;
                    }

                    cf = cf.toUpperCase();

                    set1 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    set2 = "ABCDEFGHIJABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    setpari = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    setdisp = "BAKPLCQDREVOSFTGUHMINJWZYX";
                    s = 0;

                    for (i = 1; i <= 13; i += 2) {
                        s += setpari.indexOf(set2.charAt(set1.indexOf(cf.charAt(i))));
                    }

                    for (i = 0; i <= 14; i += 2) {
                        s += setdisp.indexOf(set2.charAt(set1.indexOf(cf.charAt(i))));
                    }

                    if (s % 26 !== cf.charCodeAt(15) - 'A'.charCodeAt(0)) {
                        return false;
                    }

                    return true;
                };

                var setValid = function(field) {

                    field.$setValidity('parse', true);
                    field.$setValidity('pattern', true);
                    scope.invalidInput = false;
                };

                var setInvalid = function(field) {

                    field.$setValidity('parse', false);
                    field.$setValidity('pattern', false);
                    scope.invalidInput = true;
                };

                var checkValidity = function() {

                    if (!ngModelController.$viewValue && scope.inputRequired) {

                        setInvalid(ngModelController);
                        return;
                    }

                    if (pattern.test(ngModelController.$viewValue)) {

                        if (scope.type === 'cf') {

                            if (isCF(ngModelController.$viewValue)) {

                                setValid(ngModelController);

                            } else {

                                setInvalid(ngModelController);
                            }

                        } else {

                            setValid(ngModelController);
                        }

                    } else {

                        setInvalid(ngModelController);
                    }
                };



                if (!ngModelController) {
                    return;
                }

                switch (scope.type) {

                    case 'numeric':
                        pattern = NUMERIC_REGEXP;
                        break;

                    case 'alpha':
                        pattern = ALPHA_REGEXP;
                        break;

                    case 'alphanumeric':
                        pattern = ALPHANUMERIC_REGEXP;
                        break;

                    case 'cap':
                        pattern = CAP_REGEXP;
                        break;

                    case 'cf':
                        pattern = ALPHANUMERIC_REGEXP;
                        break;

                    case 'currency':
                        pattern = CURRENCY_REGEXP;
                        break;

                    case 'email':
                        pattern = EMAIL_REGEXP;
                        break;

                    case 'tel':
                        pattern = PHONENUMBER_REGEXP;
                        break;

                    case 'pwd':
                        pattern = PASSWORD_REGEXP;
                        break;

                    default:
                        pattern = PASSWORD_REGEXP;
                        break;
                }

                ngModelController.$parsers.push(function(data) {

                    scope.invalidInput = false;
                    scope.serviceInvalidInput = false;

                    if (scope.onlyValid) {

                        if (data !== '' && !pattern.test(data)) {
                            data = lastValidValue;
                        }
                    }

                    lastValidValue = angular.copy(data);

                    if (scope.type === 'cf') {
                        data = data.toUpperCase();
                    }

                    ngModelController.$setViewValue(data);
                    ngModelController.$render();

                    if (!scope.validationEvent) {
                        checkValidity();
                    }

                    if (scope.onChangeFn && lastCommittedValue !== data) {
                        lastCommittedValue = data;
                        scope.onChangeFn();
                    }

                    return data;
                });

                if (scope.validationEvent) {

                    scope.$on(scope.validationEvent, function() {
                        checkValidity();
                    });
                }

                $timeout(function() {

                    if (scope.onlyValid) {

                        if (ngModelController.$viewValue !== '' && !pattern.test(ngModelController.$viewValue)) {
                            ngModelController.$viewValue = lastValidValue;
                        }
                    }

                    lastValidValue = angular.copy(ngModelController.$viewValue);
                });
            }
        };
    }]);

})();