(function() {

    'use strict';

    var ispTable = angular.module('ispTable', ['ispButton']);

    ispTable.directive('ispTable', [function() {

        return {
            templateUrl: 'assets/directives/ispTable/ispTable.tpl.html',
            scope: {
                labels: '=',
                contents: '=',
                rowsPerPage: '@',
                gap: '@'
            },

            controller: function($scope) {

                $scope.currentPage = 0;
                $scope.gap = Number($scope.gap);
                $scope.sortLabels = [];

                angular.forEach($scope.labels, function(label) {
                    $scope.sortLabels.push(label.replace(" ", "_"));
                });

                angular.forEach($scope.contents, function(content, i) {
                    angular.forEach($scope.labels, function(label, j) {
                        $scope.contents[i]["'" + $scope.sortLabels[j] + "'"] = $scope.contents[i][$scope.labels[j]];
                    })
                });

                $scope.sort = {
                    sortingOrder: $scope.sortLabels[0],
                    reverse: false
                };

                $scope.prevPage = function() {
                    if ($scope.currentPage > 0) {
                        $scope.currentPage--;
                    }
                };

                $scope.nextPage = function() {
                    if ($scope.currentPage < $scope.pages - 1) {
                        $scope.currentPage++;
                    }
                };

                $scope.setPage = function(page) {
                    $scope.currentPage = page;
                };

                $scope.groupToPages = function() {

                    $scope.pages = 0;

                    for (var i = 0; i < $scope.contents.length; i++) {
                        if (i % $scope.rowsPerPage === 0) {
                            $scope.pages++;
                        }
                    }
                };

                $scope.range = function(size, start, end) {

                    var ret = [];

                    if (size < end) {
                        end = size;
                        start = size - $scope.gap;
                    }

                    if (start < 0) {
                        start = 0;
                    }

                    for (var i = start; i < end; i++) {
                        ret.push(i);
                    }

                    return ret;
                };

                $scope.sortBy = function(newSortingOrder) {

                    var sort = $scope.sort;

                    if (sort.sortingOrder == newSortingOrder) {
                        sort.reverse = !sort.reverse;
                    }

                    sort.sortingOrder = newSortingOrder;
                };

                $scope.groupToPages();
            }
        };
    }]);

})();